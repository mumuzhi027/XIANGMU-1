// 获取各页面元素
const screeningButton = document.getElementById('screening-button');
const feedbackButton = document.getElementById('feedback-button');
const mainPage = document.querySelector('.main-page');
const screeningPage = document.querySelector('.screening-page');
const yearPage = document.querySelector('.year-page');
const feedbackPage = document.querySelector('.feedback-page');
const typePage = document.querySelector('.type-page');
const questionSinglePage = document.getElementById('question-single-page');
const questionMultiplePage = document.getElementById('question-multiple-page');
const questionSingleExplanationPage = document.getElementById('question-single-explanation-page');
const questionMultipleExplanationPage = document.getElementById('question-multiple-explanation-page');

// 点击初始返回，返回主界面
function Gotomainpage(){
    window.location.href = '../mainpage/HomePage.html';
}

// 题目相关变量
let singleSelectedOption = null;
let multipleSelectedOptions = [];
const singleOptions = document.querySelectorAll('.option-single-item');
const multipleOptions = document.querySelectorAll('.option-multiple-item');
let startTime;
// 存储每个科目的完成题目数
const completedCountBySubject = {
    math: 0,
    algebra: 0,
    english: 0,
    physics: 0
};
let currentSubject;
let currentQuestionIndex = 0;
let questionTimes = [];

// 模拟题目数据
let questions = [
    // 单选题
    {
        type:'single',
        text: '题干文字题干文字题干文字题干文字题干文字题干文字题干文字题干文字',
        options: ['A. 选项文字选项文字选项文字', 'B. 选项文字选项文字选项文字', 'C. 选项文字选项文字选项文字', 'D. 选项文字选项文字选项文字'],
        answer: 'A',
        explanation: '解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字'
    },
    // 多选题
    {
        type:'multiple',
        text: '题干文字题干文字题干文字题干文字题干文字题干文字题干文字题干文字',
        options: ['A. 选项文字选项文字选项文字', 'B. 选项文字选项文字选项文字', 'C. 选项文字选项文字选项文字', 'D. 选项文字选项文字选项文字'],
        answer: ['A', 'B'],
        explanation: '解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字解析文字'
    }
];

// 点击筛选按钮显示筛选页面
function showScreeningPage() {
    mainPage.style.display = 'none';
    screeningPage.style.display = 'block';
}

// 点击反馈按钮显示反馈页面
function showFeedbackPage() {
    mainPage.style.display = 'none';
    feedbackPage.style.display = 'block';
}

// 返回主页面
function backToMainPage() {
    screeningPage.style.display = 'none';
    mainPage.style.display = 'block';
}

// 从年份页面返回科目页面
function backToSubjectPage() {
    yearPage.style.display = 'none';
    screeningPage.style.display = 'block';
}

// 从反馈页面返回主页面
function backToMainFromFeedbackPage() {
    feedbackPage.style.display = 'none';
    mainPage.style.display = 'block';
}

// 点击科目显示年份选择页面
function showYearPage(subject) {
    currentSubject = subject;
    yearPage.style.display = 'block';
    screeningPage.style.display = 'none';
}

// 点击年份显示题型选择页面
function showTypePage(year) {
    typePage.style.display = 'block';
    yearPage.style.display = 'none';
}

// 从题型选择页面返回年份页面
function backToYearPage() {
    yearPage.style.display = 'block';
    typePage.style.display = 'none';
}

// 点击单选题型显示单选题答题页面
function showSingleQuestionPage() {
    startTimer();
    questionSinglePage.style.display = 'block';
    typePage.style.display = 'none';
    updateCompletedCountDisplay();
    setQuestionData(questionSinglePage, questions[currentQuestionIndex]);
}

// 点击多选题型显示多选题答题页面
function showMultipleQuestionPage() {
    startTimer();
    questionMultiplePage.style.display = 'block';
    typePage.style.display = 'none';
    updateCompletedCountDisplay();
    setQuestionData(questionMultiplePage, questions[currentQuestionIndex]);
}

// 设置题目数据到页面
function setQuestionData(page, question) {
    const questionTextElement = page === questionSinglePage? document.getElementById('question-single-text') : document.getElementById('question-multiple-text');
    questionTextElement.textContent = question.text;
    const optionElements = page === questionSinglePage? singleOptions : multipleOptions;
    optionElements.forEach((option, index) => {
        option.textContent = question.options[index];
    });
}

// 返回上一页函数
function goBack() {
    questionSinglePage.style.display = 'none';
    questionMultiplePage.style.display = 'none';
    typePage.style.display = 'block';
}

// 更新时间显示
function updateTime() {
    const currentTime = new Date();
    const elapsedTime = currentTime - startTime;
    const minutes = Math.floor(elapsedTime / (1000 * 60));
    const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
    const timerSingle = document.getElementById('timer-single');
    const timerMultiple = document.getElementById('timer-multiple');
    timerSingle.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    timerMultiple.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

// 启动时间计时
function startTimer() {
    startTime = new Date();
    setInterval(updateTime, 1000);
}

// 单选题选择选项函数
function selectSingleOption(option) {
    if (singleSelectedOption) {
        singleSelectedOption.classList.remove('selected');
    }
    option.classList.add('selected');
    singleSelectedOption = option;
}

// 多选题切换选项函数
function toggleMultipleOption(option) {
    option.classList.toggle('selected');
    if (option.classList.contains('selected')) {
        multipleSelectedOptions.push(option);
    } else {
        multipleSelectedOptions = multipleSelectedOptions.filter(opt => opt!== option);
    }
}

// 更新完成题目数显示
function updateCompletedCountDisplay() {
    const completedSingle = document.getElementById('completed-single');
    const completedMultiple = document.getElementById('completed-multiple');
    completedSingle.textContent = completedCountBySubject[currentSubject];
    completedMultiple.textContent = completedCountBySubject[currentSubject];
}

// 提交单选题答案函数
function submitSingleAnswer() {
    if (singleSelectedOption) {
        const question = questions[currentQuestionIndex];
        const isCorrect = question.answer === singleSelectedOption.textContent;
        const optionElements = document.querySelectorAll('.option-single-item');
        optionElements.forEach(option => {
            if (option.textContent === question.answer) {
                option.classList.add('correct');
            }
            if (option === singleSelectedOption) {
                if (isCorrect) {
                    option.classList.add('correct');
                } else {
                    option.classList.add('incorrect');
                }
            }
        });
        showSingleExplanationPage(question);
    } else {
        alert('请选择一个单选题答案');
    }
}

// 提交多选题答案函数
function submitMultipleAnswer() {
    if (multipleSelectedOptions.length > 0) {
        const question = questions[currentQuestionIndex];
        const userAnswers = multipleSelectedOptions.map(opt => opt.textContent);
        const correctAnswers = question.answer;
        const optionElements = document.querySelectorAll('.option-multiple-item');
        optionElements.forEach(option => {
            if (correctAnswers.includes(option.textContent)) {
                if (userAnswers.includes(option.textContent)) {
                    option.classList.add('correct');
                } else {
                    option.classList.add('incorrect');
                }
            } else if (userAnswers.includes(option.textContent)) {
                option.classList.add('incorrect');
            }
        });
        showMultipleExplanationPage(question);
    } else {
        alert('请选择至少一个多选题答案');
    }
}

// 显示单选题解析页面
function showSingleExplanationPage(question) {
    questionTimes[currentQuestionIndex] = new Date() - startTime;
    const questionTextElement = document.getElementById('question-single-text-explanation');
    const explanationTextElement = document.getElementById('explanation-text-single');
    const optionContainer = document.querySelector('.options-single-explanation');
    questionTextElement.textContent = question.text;
    explanationTextElement.textContent = question.explanation;
    optionContainer.innerHTML = '';
    question.options.forEach(option => {
        const optionElement = document.createElement('div');
        optionElement.textContent = option;
        optionElement.classList.add('option-single-item-explanation');
        const isCorrect = option === question.answer;
        if (isCorrect) {
            optionElement.classList.add('correct');
        }
        optionContainer.appendChild(optionElement);
    });
    questionSinglePage.style.display = 'none';
    questionSingleExplanationPage.style.display = 'block';
    const timerExplanation = document.getElementById('timer-single-explanation');
    const elapsedTime = questionTimes[currentQuestionIndex];
    const minutes = Math.floor(elapsedTime / (1000 * 60));
    const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
    timerExplanation.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

// 显示多选题解析页面
function showMultipleExplanationPage(question) {
    questionTimes[currentQuestionIndex] = new Date() - startTime;
    const questionTextElement = document.getElementById('question-multiple-text-explanation');
    const explanationTextElement = document.getElementById('explanation-text-multiple');
    const optionContainer = document.querySelector('.options-multiple-explanation');
    questionTextElement.textContent = question.text;
    explanationTextElement.textContent = question.explanation;
    optionContainer.innerHTML = '';
    question.options.forEach(option => {
        const optionElement = document.createElement('div');
        optionElement.textContent = option;
        optionElement.classList.add('option-multiple-item-explanation');
        const isCorrect = question.answer.includes(option);
        if (isCorrect) {
            optionElement.classList.add('correct');
        }
        optionContainer.appendChild(optionElement);
    });
    questionMultiplePage.style.display = 'none';
    questionMultipleExplanationPage.style.display = 'block';
    const timerExplanation = document.getElementById('timer-multiple-explanation');
    const elapsedTime = questionTimes[currentQuestionIndex];
    const minutes = Math.floor(elapsedTime / (1000 * 60));
    const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
    timerExplanation.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

// 返回单选题答题页面
function goBackToSingleQuestion() {
    questionSingleExplanationPage.style.display = 'none';
    questionSinglePage.style.display = 'block';
    const optionElements = document.querySelectorAll('.option-single-item');
    optionElements.forEach(option => {
        option.classList.remove('correct', 'incorrect','selected');
    });
    singleSelectedOption = null;
}

// 返回多选题答题页面
function goBackToMultipleQuestion() {
    questionMultipleExplanationPage.style.display = 'none';
    questionMultiplePage.style.display = 'block';
    const optionElements = document.querySelectorAll('.option-multiple-item');
    optionElements.forEach(option => {
        option.classList.remove('correct', 'incorrect','selected');
    });
    multipleSelectedOptions = [];
}

// 上一题（单选题）
function prevSingleQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        questionSingleExplanationPage.style.display = 'none';
        questionSinglePage.style.display = 'block';
        setQuestionData(questionSinglePage, questions[currentQuestionIndex]);
        const optionElements = document.querySelectorAll('.option-single-item');
        optionElements.forEach(option => {
            option.classList.remove('correct', 'incorrect','selected');
        });
        singleSelectedOption = null;
        const timerExplanation = document.getElementById('timer-single-explanation');
        const elapsedTime = questionTimes[currentQuestionIndex];
        const minutes = Math.floor(elapsedTime / (1000 * 60));
        const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
        timerExplanation.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
}

// 下一题（单选题）
function nextSingleQuestion() {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        questionSingleExplanationPage.style.display = 'none';
        questionSinglePage.style.display = 'block';
        setQuestionData(questionSinglePage, questions[currentQuestionIndex]);
        const optionElements = document.querySelectorAll('.option-single-item');
        optionElements.forEach(option => {
            option.classList.remove('correct', 'incorrect','selected');
        });
        singleSelectedOption = null;
        startTimer();
    }
}

// 上一题（多选题）
function prevMultipleQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        questionMultipleExplanationPage.style.display = 'none';
        questionMultiplePage.style.display = 'block';
        setQuestionData(questionMultiplePage, questions[currentQuestionIndex]);
        const optionElements = document.querySelectorAll('.option-multiple-item');
        optionElements.forEach(option => {
            option.classList.remove('correct', 'incorrect','selected');
        });
        multipleSelectedOptions = [];
        const timerExplanation = document.getElementById('timer-multiple-explanation');
        const elapsedTime = questionTimes[currentQuestionIndex];
        const minutes = Math.floor(elapsedTime / (1000 * 60));
        const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
        timerExplanation.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
}

// 下一题（多选题）
function nextMultipleQuestion() {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        questionMultipleExplanationPage.style.display = 'none';
        questionMultiplePage.style.display = 'block';
        setQuestionData(questionMultiplePage, questions[currentQuestionIndex]);
        const optionElements = document.querySelectorAll('.option-multiple-item');
        optionElements.forEach(option => {
            option.classList.remove('correct', 'incorrect','selected');
        });
        multipleSelectedOptions = [];
        startTimer();
    }
}

// 初始化函数
function init() {
    // 为各按钮添加事件监听器
    screeningButton.addEventListener('click', showScreeningPage);
    feedbackButton.addEventListener('click', showFeedbackPage);

    // 修改科目按钮的点击事件，传递科目参数
    const subjectButtons = document.querySelectorAll('.subject-button');
    subjectButtons.forEach(button => {
        button.addEventListener('click', () => {
            showYearPage(button.id);
        });
    });

    // 年份按钮点击事件
    const yearButtons = document.querySelectorAll('.year-button');
    yearButtons.forEach(button => {
        button.addEventListener('click', () => {
            showTypePage(button.id);
        });
    });

    // 题型按钮点击事件
    const typeButtons = document.querySelectorAll('.type-button');
    typeButtons.forEach(button => {
        if (button.id ==='single') {
            button.addEventListener('click', showSingleQuestionPage);
        } else {
            button.addEventListener('click', showMultipleQuestionPage);
        }
    });

    // 单选题选项点击事件
    singleOptions.forEach(option => {
        option.addEventListener('click', () => {
            selectSingleOption(option);
        });
    });

    // 多选题选项点击事件
    multipleOptions.forEach(option => {
        option.addEventListener('click', () => {
            toggleMultipleOption(option);
        });
    });

    // 提交按钮点击事件
    document.getElementById('submit-single-button').addEventListener('click', submitSingleAnswer);
    document.getElementById('submit-multiple-button').addEventListener('click', submitMultipleAnswer);

    // 返回按钮点击事件
    document.getElementById('back-to-previous').addEventListener('click', goBack);
    document.getElementById('back-to-previous-multiple').addEventListener('click', goBack);
    document.getElementById('back-to-single-question').addEventListener('click', goBackToSingleQuestion);
    document.getElementById('back-to-multiple-question').addEventListener('click', goBackToMultipleQuestion);

    // 上一题和下一题按钮点击事件
    document.getElementById('prev-question-single').addEventListener('click', prevSingleQuestion);
    document.getElementById('next-question-single').addEventListener('click', nextSingleQuestion);
    document.getElementById('prev-question-multiple').addEventListener('click', prevMultipleQuestion);
    document.getElementById('next-question-multiple').addEventListener('click', nextMultipleQuestion);
}

window.onload = init;